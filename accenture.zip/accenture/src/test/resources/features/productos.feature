Feature: Pruebas de la API de Productos en Platzi

  Background:
    * url baseUrl
    * path 'products'

  Scenario: Obtener lista de productos exitosamente
    When method get
    Then status 200

  Scenario: Obtener un solo producto por ID
    Given path '20'
    When method get
    Then status 200

  Scenario: Validar estructura del JSON de un producto
    Given path '20'
    When method get
    Then status 200
    And match response.id == '#number'
    And match response.title == '#string'

  Scenario: Buscar un producto con ID inexistente
    Given path '0'
    When method get
    Then status 400

  Scenario: Buscar un producto con ID invalido
    Given path 'not-an-id'
    When method get
    Then status 400