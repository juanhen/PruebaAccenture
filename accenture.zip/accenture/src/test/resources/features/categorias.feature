Feature: Pruebas de la API de Categorias en Platzi

  Background:
    * url baseUrl
    * path 'categories'

  Scenario: Obtener todas las categorias exitosamente
    When method get
    Then status 200

  Scenario: Obtener una sola categoria por ID
    Given path '1'
    When method get
    Then status 200

  Scenario: Validar campos obligatorios de categoria
    Given path '1'
    When method get
    Then status 200
    And match response.name == '#string'

  Scenario: Buscar categoria con ID inexistente
    Given path '0'
    When method get
    Then status 400

  Scenario: Buscar categoria con ID invalido
    Given path 'xyz'
    When method get
    Then status 400