# Prueba Técnica QA Automation - Backend (Accenture)

## 📌 Descripción del Proyecto
Este proyecto contiene la automatización de pruebas para la API pública de Platzi Fake Store, cubriendo los servicios de **Productos**, **Categorías** y **Usuarios**. Se han implementado un total de 15 escenarios de prueba bajo el enfoque de BDD (Behavior Driven Development).

## 🛠️ Herramientas Utilizadas
* [cite_start]**Lenguaje:** Java 17 [cite: 131]
* [cite_start]**Framework de Automatización:** Karate Framework [cite: 131]
* [cite_start]**Gestor de Dependencias:** Gradle [cite: 131]
* [cite_start]**IDE:** Visual Studio Code [cite: 67]
* [cite_start]**Reportes:** Karate Reports (HTML) [cite: 240]

## 🧠 Análisis y Pensamiento QA
Para cumplir con los estándares de calidad, el diseño de las pruebas se centró en los siguientes pilares:

1. **Validación de Estructura (Schema Validation):** No solo se validó que el servicio responda, sino que los datos devueltos cumplan con el formato esperado (ej. IDs como números, correos y títulos como cadenas de texto)[cite: 193, 197, 724].
2. **Escenarios Negativos:** Se incluyeron pruebas para manejar errores de cliente (400 Bad Request) y recursos no encontrados (404 Not Found), asegurando que la API gestione correctamente entradas inválidas o IDs inexistentes[cite: 40, 192, 723].
3. **Mantenibilidad:** Se utilizó un archivo `karate-config.js` para centralizar la URL base y variables globales, facilitando cambios futuros en el entorno[cite: 66, 121, 169].
4. **Resiliencia ante Datos Inestables:** Dado que es una API pública y los datos cambian constantemente, se optó por validaciones de tipos de datos (#string, #number) en lugar de valores exactos, garantizando que las pruebas sean robustas y no fallen por cambios de terceros[cite: 761, 767].

## 🚀 Cómo Ejecutar las Pruebas
Para ejecutar el proyecto localmente, asegúrese de tener instalado Java 17 y siga estos pasos:

1. Clonar el repositorio.
2. Abrir una terminal en la raíz del proyecto.
3. Ejecutar el comando:
   .\gradlew test