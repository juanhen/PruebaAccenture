Feature: Pruebas de la API de Usuarios en Platzi

  Background:
    * url baseUrl
    * path 'users'

  Scenario: Obtener todos los usuarios exitosamente
    When method get
    Then status 200

  Scenario: Obtener un usuario especifico por ID
    Given path '1'
    When method get
    Then status 200

  Scenario: Validar que el correo del usuario sea texto
    Given path '1'
    When method get
    Then status 200
    And match response.email == '#string'

  Scenario: Intentar crear un usuario con datos invalidos
    # Enviamos un email con formato incorrecto para forzar el error 400
    Given request { "name": "QA User", "email": "esto-no-es-un-email", "password": "123", "avatar": "http://placeimg.com/640/480/any" }
    When method post
    Then status 400

  Scenario: Buscar un usuario con ID inexistente
    Given path '0'
    When method get
    Then status 400