function fn() {
  var config = {
    // URL oficial y actualizada
    baseUrl: 'https://api.escuelajs.co/api/v1/'
  };
  return config;
}