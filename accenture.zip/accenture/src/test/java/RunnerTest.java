import com.intuit.karate.junit5.Karate;

public class RunnerTest {
    
    @Karate.Test
    Karate testAll() {
        // Ejecuta todo lo que esté en la carpeta features
        return Karate.run("classpath:features");
    }
}